Relative Velocity Energy Converter
----------------------------------

Just run `ant && ant run`